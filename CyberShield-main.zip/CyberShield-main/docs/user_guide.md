# SME CyberShield User Guide

## 1) Install and Run (Step by Step)

1. Ensure Python 3.10+ is installed.
2. Open a terminal in the project folder.
3. Create a virtual environment:
   - `python -m venv .venv`
4. Activate environment:
   - Windows PowerShell: `.\.venv\Scripts\Activate.ps1`
5. Install dependencies:
   - `pip install -r requirements.txt`
6. Launch dashboard:
   - `streamlit run app.py`
7. Open the local URL shown in terminal.

## 2) Using the 4 Dashboard Pages

### Page 1: Govern & Identify
- Review asset inventory and criticality levels.
- Filter and inspect risk register by severity.
- Analyze risk concentration via 5x5 heatmap.
- Track governance policy checklist completion.

### Page 2: Protect & Detect
- Monitor control implementation coverage gauge.
- Toggle controls as implemented/not implemented.
- Review detection rules and run simulated alerts.
- Prioritize controls with cost-impact matrix.

### Page 3: Respond & Recover
- Open playbooks for ransomware, phishing, and breach scenarios.
- Review recovery plans with RTO/RPO data.
- Log incidents, update status, and monitor timeline.
- Simulate recovery progress against RTO targets.

### Page 4: Integration Dashboard
- Inspect NIST maturity radar (current vs target).
- Compare risk before/after framework application.
- Review executive metrics and scenario comparison.
- Export PDF and JSON reports.

## 3) Running the 3 SME Scenarios

1. Use sidebar scenario selector:
   - Retail (Ransomware)
   - Services (Phishing)
   - Manufacturing (Breach)
2. On switch, all derived metrics refresh automatically.
3. Baseline deltas reset per selected scenario.

## 4) Logging and Tracking Incidents

1. Open `Respond & Recover`.
2. Fill incident form: type, severity, description.
3. Submit `Log Incident`.
4. Use status advance buttons to move lifecycle:
   - Detected -> Contained -> Recovering -> Resolved
5. Watch progress in table and timeline chart.

## 5) Exporting Reports

1. Open `Integration Dashboard`.
2. Click `Generate PDF Report` to download summary report.
3. Click `Export JSON` to download structured data.

## 6) Assumptions and Limitations

- Current incident tracker is in-memory session state (not persistent database).
- Risk reduction in dashboard is a simulation model (default 25% improvement).
- Maturity scores are heuristic estimates based on available controls/assets/policies.
- Asset coverage in sample scenarios assumes complete inventory fixture data.
- Production deployment should add authentication, audit logs, and encrypted storage.
