# SME CyberShield Technical Documentation

## 1) System Architecture (Text Diagram)

`Streamlit UI (app.py + pages/*)`  
-> reads/writes `st.session_state`  
-> calls backend services (`module1`..`module4`)  
-> uses reusable helpers (`utils/charts.py`, `utils/export.py`)  
-> outputs dashboards, alerts, maturity analytics, and downloadable reports.

Core layers:
- **Presentation Layer**: Streamlit multi-page UI.
- **Application Layer**: Scenario orchestration and integration calculations.
- **Domain Layer**: Governance, risk, controls, detection, incident/recovery logic.
- **Data Layer**: In-memory scenario fixtures from `sample_data.py`; schema contracts in `data_schemas.py`.

## 2) Data Flow Between Modules

1. `sample_data.py` provides scenario assets, controls, policies, playbooks, recovery plans.
2. `module1_govern_identify.py` generates risk register from asset inventory.
3. `module2_protect_detect.py` computes control coverage and simulates alerts.
4. `module3_respond_recover.py` provides playbooks/plans and incident lifecycle tracking.
5. `module4_integration.py` aggregates risk data, computes maturity, heatmaps, and export report payload.
6. Streamlit pages render data and user actions mutate session state; derived metrics are recalculated.

## 3) Function Reference (from Module Docstrings)

### `module1_govern_identify.py`
- `get_governance_policies()`: Returns SME governance policy templates.
- `get_asset_inventory()`: Returns sample asset inventory.
- `calculate_risk_score(likelihood, impact)`: Computes score and risk level.
- `generate_risk_register(assets)`: Builds register entries with controls.

### `module2_protect_detect.py`
- `get_protective_controls()`: Returns protective controls with implementation state.
- `get_detection_mechanisms()`: Returns detection rules and response actions.
- `calculate_control_coverage(controls)`: Returns implemented controls percent.
- `simulate_detection_event(event_type)`: Returns simulated alert payload.

### `module3_respond_recover.py`
- `get_incident_playbooks()`: Returns incident response playbook templates.
- `get_recovery_plans()`: Returns recovery planning templates.
- `IncidentTracker.log_incident(...)`: Adds incident, initial status `Detected`.
- `IncidentTracker.update_status(...)`: Updates lifecycle status.
- `IncidentTracker.get_recovery_progress(...)`: Returns progress 0-100.
- `IncidentTracker.get_all_incidents()`: Returns full incident list.

### `module4_integration.py`
- `aggregate_risk_data(risk_register)`: Summary counts and overall risk score.
- `calculate_nist_maturity(controls, playbooks, policies, assets)`: 0-5 scores per NIST function.
- `generate_risk_heatmap_data(risk_register)`: Returns 5x5 likelihood-impact matrix.
- `generate_full_report(all_data)`: Builds export-ready report dictionary.
- `run_sme_scenario(scenario_name)`: Executes full scenario pipeline.

## 4) Dependencies and Version Requirements

- Python: 3.10+
- Runtime:
  - `streamlit`
  - `pandas`
  - `plotly`
  - `fpdf2`
- Testing:
  - `pytest`
  - `pytest-cov` (recommended for coverage output in automation)

## 5) Known Limitations

- No persistent storage for incidents or checklist states beyond session.
- Maturity and risk-reduction metrics are heuristic/scenario-driven.
- No authentication/authorization model in current prototype.
- No asynchronous event pipeline; simulated detections are manual triggers.
- PDF output is concise and does not yet include embedded chart images.
