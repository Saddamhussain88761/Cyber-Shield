# Final Academic Report Template — SME CyberShield

## 1. Introduction (Approx. 200 words)

Small and medium-sized enterprises (SMEs) face growing cybersecurity risk due to limited budgets, constrained expertise, and increasing dependency on digital platforms. This project presents **SME CyberShield**, a modular cybersecurity risk management dashboard aligned with **NIST CSF 2.0** and **ISO 27005**. The design focuses on practical decision support for governance, risk visibility, control implementation, incident response, and recovery planning.  

The system is organized into four modules: Govern & Identify, Protect & Detect, Respond & Recover, and Integration Dashboard. Together, these modules provide an operational workflow from asset inventory and risk scoring to control tracking, incident lifecycle management, and executive reporting. The interface is implemented using Streamlit with interactive Plotly visualizations, while backend analytics are delivered through Python modules using structured JSON-serializable data models.  

The key objective is to bridge strategic cybersecurity guidance and day-to-day SME operations by offering an accessible, scenario-driven dashboard. Three domain-relevant scenarios (retail ransomware, services phishing, manufacturing breach) are used to evaluate practical usefulness, coverage, and performance against selected metrics. The outcome demonstrates how lightweight decision-support tooling can raise cyber readiness without requiring enterprise-scale security infrastructure.

## 2. Literature Review Summary (Approx. 300 words)

The foundation of this project is the **NIST Cybersecurity Framework (CSF) 2.0**, which expands cybersecurity governance and introduces practical profiles suitable for organizations with varying maturity levels. NIST emphasizes six core functions—Govern, Identify, Protect, Detect, Respond, and Recover—offering a lifecycle-oriented structure that is highly applicable to SMEs adopting incremental improvements.  

**ISO 27005** complements NIST by providing a systematic risk management method centered on context definition, risk identification, analysis, evaluation, and treatment. Its emphasis on repeatable assessment and treatment plans informs the risk register logic and recommendation pathways in this tool.  

Threat intelligence from the **Verizon 2024 Data Breach Investigations Report (DBIR)** highlights continued dominance of credential abuse, phishing, and exploitation of vulnerabilities. These findings justify the inclusion of MFA, patching, email protections, and incident playbooks as baseline controls.  

Regional and sector-level risk trends in **ENISA 2025** reporting indicate persistent exposure in supply chains and operational technology environments. This supports scenario-based modeling across retail, services, and manufacturing contexts, especially for third-party compromise and breach pathways.  

Industry analyses such as **Heimdal Security 2025** continue to stress operational simplicity, endpoint hygiene, and measurable resilience outcomes for smaller organizations. These recommendations influenced dashboard decisions such as control coverage gauges, quick-priority matrices, and exportable executive summaries for leadership communication.  

Collectively, the literature indicates that SMEs benefit from frameworks only when translated into clear operational artifacts. Therefore, this project intentionally maps framework guidance into practical UI workflows, measurable KPIs, and reusable templates rather than static compliance checklists.

## 3. Research Design / Methodology (Approx. 200 words)

This project follows a **Design Science Research (DSR)** approach. The problem domain is defined as SME difficulty in operationalizing cybersecurity frameworks due to resource constraints and fragmented practices. The artifact is a multi-module dashboard that integrates risk analytics, controls management, and incident/recovery planning into a cohesive workflow.  

The design process involved: (1) deriving core functional requirements from NIST CSF 2.0 and ISO 27005; (2) building modular backend services to represent governance, controls, incidents, and maturity; (3) implementing a Streamlit-based interactive interface; and (4) evaluating with predefined SME scenarios and heuristic checks.  

Evaluation uses both technical and practical criteria: automated test coverage with pytest, scenario metric thresholds (e.g., control coverage, maturity average, risk reduction simulation), and a Nielsen-based usability review. This triangulation balances functional correctness with usability relevance for non-expert operators.  

The DSR cycle is iterative: implementation findings feed into refinements in controls, visual summaries, and export workflows. The result is a demonstrable artifact intended for educational and prototype decision-support use, with explicit documentation of assumptions and limitations for future extension.

## 4. Implementation Summary (Per Module, ~100 words each)

### Module 1 — Govern & Identify
Implements governance policy templates, asset inventory modeling, risk scoring, and risk register generation. Assets are scored using a likelihood-impact matrix, producing risk labels and treatment recommendations. The output forms the baseline for subsequent dashboard analytics and maturity calculations.

### Module 2 — Protect & Detect
Provides protective controls and detection mechanisms aligned with common SME needs. Includes live control coverage calculations, alert simulation, and a priority matrix to support implementation sequencing. The module operationalizes preventive and detective measures in measurable form.

### Module 3 — Respond & Recover
Defines incident playbooks and recovery plans with RTO/RPO considerations. An in-memory incident tracker captures lifecycle progression from detection to resolution and supports progress measurement. This module strengthens continuity planning and structured response workflows.

### Module 4 — Integration Dashboard
Aggregates outputs from all modules into executive indicators, maturity scoring, heatmaps, scenario comparisons, and exportable reports. It acts as the orchestration layer for scenario execution and management-level decision support.

## 5. Testing Results

Fill with latest run outputs:
- **Pytest pass rate:** `<value>%`
- **Coverage:** `<value>%`
- **Scenario targets met:** `<yes/no by metric>`
- **Heuristic average score:** `<value>/5`
- **NIST quick-start supported items:** `<value>/8`

## 6. Presentation of Results

Reference dashboard outputs:
- Risk exposure heatmap (likelihood vs impact)
- NIST maturity radar (current vs target)
- Control coverage gauge
- Scenario comparison grouped bars
- Incident timeline and recovery simulator

Key findings to summarize:
- Highest recurring threat categories
- Control gaps by scenario
- Maturity improvements after full control implementation
- Recovery readiness against RTO thresholds

## 7. Conclusions (Approx. 150 words)

SME CyberShield demonstrates that NIST CSF 2.0 and ISO 27005 concepts can be translated into practical, low-friction operational tooling for SMEs. The modular architecture enables progressive adoption: organizations can start with inventory and risk visibility, then expand into controls, incident management, and executive reporting. Scenario-driven outputs and automated evaluations show that meaningful risk insight can be achieved without complex enterprise platforms.  

The prototype is effective for education, planning, and governance communication; however, production deployment requires stronger persistence, identity controls, and external integrations. Future work should include role-based access, SIEM connector APIs, historical analytics, and richer evidence-based maturity scoring. Overall, the project offers a strong baseline for bridging framework guidance and day-to-day cyber risk decisions in small and medium organizations.

## 8. Critical Self-Evaluation Template (100 words per student)

### Sher Dil Awan — Govern & Identify
`[Write 100 words on design decisions, challenges, and lessons learned.]`

### Faizan Javed — Protect & Detect
`[Write 100 words on implementation quality, validation, and improvements.]`

### Ali Shan — Respond & Recover
`[Write 100 words on incident/recovery modeling choices and limitations.]`

### Saddam Hussain — Integration & Dashboard
`[Write 100 words on orchestration, visualization, and overall project outcomes.]`
