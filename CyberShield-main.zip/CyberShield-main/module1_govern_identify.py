"""Module 1 - Govern & Identify.

Implements governance templates, asset inventory, and risk register generation
for an SME retail environment aligned with NIST CSF 2.0 and ISO 27005 thinking.
"""

from __future__ import annotations

from typing import Dict, List, Tuple

import pandas as pd

from data_schemas import Asset, GovernancePolicy, RiskRegisterEntry, RiskLevel


def get_governance_policies() -> List[GovernancePolicy]:
    """Return SME governance policy templates for a retail business."""
    return [
        {
            "id": "GOV-001",
            "title": "Information Security Governance Charter",
            "description": "Defines cybersecurity oversight, accountability, and decision rights.",
            "nist_function": "Govern",
            "priority": "High",
            "owner_role": "Managing Director",
            "checklist": [
                "Appoint an information security lead.",
                "Define cybersecurity KPIs and quarterly review cadence.",
                "Approve annual cyber risk appetite statement.",
                "Review governance effectiveness at least annually.",
            ],
        },
        {
            "id": "GOV-002",
            "title": "Third-Party Risk Management Policy",
            "description": "Ensures suppliers and POS/payment vendors meet minimum controls.",
            "nist_function": "Govern",
            "priority": "High",
            "owner_role": "Procurement Manager",
            "checklist": [
                "Classify vendors by data access and criticality.",
                "Require security clauses in contracts.",
                "Perform annual security due diligence for critical vendors.",
                "Track remediation of identified vendor gaps.",
            ],
        },
        {
            "id": "GOV-003",
            "title": "Data Classification and Handling Policy",
            "description": "Defines data categories and handling rules for customer and operational data.",
            "nist_function": "Govern",
            "priority": "High",
            "owner_role": "Operations Manager",
            "checklist": [
                "Classify customer PII, transaction data, and internal records.",
                "Apply retention and secure disposal requirements.",
                "Limit access by role and business need.",
                "Perform spot checks on data handling practices.",
            ],
        },
        {
            "id": "GOV-004",
            "title": "Risk Assessment and Treatment Policy",
            "description": "Establishes periodic risk assessments and treatment tracking in a formal register.",
            "nist_function": "Govern",
            "priority": "Medium",
            "owner_role": "Risk Officer",
            "checklist": [
                "Run semi-annual risk assessments.",
                "Document likelihood, impact, and treatment owner.",
                "Escalate critical risks to executive review.",
                "Track closure evidence for treatment actions.",
            ],
        },
        {
            "id": "GOV-005",
            "title": "Incident Reporting and Escalation Policy",
            "description": "Defines incident severity criteria, communication channels, and legal escalation.",
            "nist_function": "Govern",
            "priority": "Medium",
            "owner_role": "IT Manager",
            "checklist": [
                "Define severity matrix and notification SLAs.",
                "Train staff on reporting suspicious activity.",
                "Maintain internal and external contact lists.",
                "Review incidents monthly for governance improvement.",
            ],
        },
    ]


def get_asset_inventory() -> List[Asset]:
    """Return realistic retail SME asset inventory sample data."""
    return [
        {
            "id": "AST-001",
            "name": "Store POS Terminal Cluster",
            "type": "Hardware",
            "owner": "Retail Operations Lead",
            "vulnerabilities": ["Outdated POS firmware", "Weak local admin password policy"],
            "criticality": "High",
        },
        {
            "id": "AST-002",
            "name": "E-commerce Web Application",
            "type": "Software",
            "owner": "Digital Commerce Manager",
            "vulnerabilities": ["Unpatched plugin", "Missing WAF tuning"],
            "criticality": "High",
        },
        {
            "id": "AST-003",
            "name": "Customer CRM Database",
            "type": "Data",
            "owner": "Head of Sales",
            "vulnerabilities": ["Broad read permissions", "Backup exposure risk"],
            "criticality": "High",
        },
        {
            "id": "AST-004",
            "name": "Accounts and Payroll System",
            "type": "Software",
            "owner": "Finance Manager",
            "vulnerabilities": ["Single-factor remote login"],
            "criticality": "Medium",
        },
        {
            "id": "AST-005",
            "name": "Office Endpoint Fleet",
            "type": "Hardware",
            "owner": "IT Support Lead",
            "vulnerabilities": ["Inconsistent AV updates", "USB policy not enforced"],
            "criticality": "Medium",
        },
        {
            "id": "AST-006",
            "name": "Payment Gateway Provider Integration",
            "type": "Third-party",
            "owner": "Procurement Manager",
            "vulnerabilities": ["Limited visibility into provider logs"],
            "criticality": "High",
        },
        {
            "id": "AST-007",
            "name": "Email and Collaboration Suite",
            "type": "Software",
            "owner": "HR Manager",
            "vulnerabilities": ["Phishing filtering gaps", "Legacy mailbox protocols enabled"],
            "criticality": "Medium",
        },
        {
            "id": "AST-008",
            "name": "Inventory Management SaaS",
            "type": "Third-party",
            "owner": "Supply Chain Manager",
            "vulnerabilities": ["Shared admin account", "No quarterly access review"],
            "criticality": "Medium",
        },
    ]


def calculate_risk_score(likelihood: int, impact: int) -> Tuple[int, RiskLevel]:
    """Calculate risk score using a 1-5 likelihood/impact matrix."""
    if not (1 <= likelihood <= 5 and 1 <= impact <= 5):
        raise ValueError("likelihood and impact must be integers from 1 to 5")

    score = likelihood * impact
    if score >= 20:
        return score, "Critical"
    if score >= 12:
        return score, "High"
    if score >= 6:
        return score, "Medium"
    return score, "Low"


def _derive_threat(asset: Asset) -> str:
    vulnerabilities_text = " ".join(asset["vulnerabilities"]).lower()
    if "phishing" in vulnerabilities_text or "mail" in asset["name"].lower():
        return "Credential compromise via phishing"
    if "firmware" in vulnerabilities_text or "unpatched" in vulnerabilities_text:
        return "Exploitation of unpatched systems"
    if asset["type"] == "Data":
        return "Unauthorized access to sensitive data"
    if asset["type"] == "Third-party":
        return "Third-party service compromise"
    return "Malware infection and lateral movement"


def _recommended_control_for_threat(threat: str) -> str:
    controls: Dict[str, str] = {
        "Credential compromise via phishing": "Enforce MFA and email security awareness training.",
        "Exploitation of unpatched systems": "Implement automated patch management and vulnerability scanning.",
        "Unauthorized access to sensitive data": "Apply least-privilege access and data encryption at rest.",
        "Third-party service compromise": "Enforce vendor risk reviews and contractual security controls.",
        "Malware infection and lateral movement": "Deploy EDR/antivirus and network segmentation.",
    }
    return controls.get(threat, "Apply baseline security hardening and monitoring.")


def generate_risk_register(assets: List[Asset]) -> List[RiskRegisterEntry]:
    """Generate risk register entries from assets.

    A pandas DataFrame is used for transformation, then converted back to a
    JSON-serializable list of dict records.
    """
    rows: List[RiskRegisterEntry] = []
    criticality_to_impact = {"High": 5, "Medium": 3, "Low": 2}

    for asset in assets:
        threat = _derive_threat(asset)
        vulnerability_count = len(asset["vulnerabilities"])
        likelihood = min(5, max(1, 2 + vulnerability_count))
        impact = criticality_to_impact.get(asset["criticality"], 2)
        risk_score, risk_level = calculate_risk_score(likelihood, impact)
        rows.append(
            {
                "asset_id": asset["id"],
                "threat": threat,
                "likelihood": likelihood,
                "impact": impact,
                "risk_score": risk_score,
                "risk_level": risk_level,
                "recommended_control": _recommended_control_for_threat(threat),
            }
        )

    df = pd.DataFrame(rows)
    return df.to_dict(orient="records")
