"""Module 3 - Respond & Recover."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Dict, List

from data_schemas import IncidentPlaybook, IncidentRecord, IncidentStatus, RecoveryPlan


def get_incident_playbooks() -> List[IncidentPlaybook]:
    """Return standardized incident response playbook templates."""
    return [
        {
            "id": "IR-001",
            "incident_type": "Ransomware",
            "severity": "Critical",
            "containment_steps": [
                "Isolate affected endpoints and servers from network.",
                "Disable compromised user and service accounts.",
                "Block known malicious indicators at firewall and EDR.",
            ],
            "communication_template": {
                "internal_msg": "Potential ransomware incident detected. Systems are isolated; do not power off affected devices.",
                "external_msg": "We are investigating a cybersecurity incident and have initiated containment procedures.",
            },
            "mitigation_steps": [
                "Identify ransomware strain and attack vector.",
                "Restore clean systems from verified backups.",
                "Reset credentials and harden exploited pathways.",
            ],
            "post_incident_checklist": [
                "Complete root cause analysis.",
                "Document regulatory and contractual notifications.",
                "Run lessons-learned workshop and update controls.",
            ],
            "estimated_recovery_hours": 48,
        },
        {
            "id": "IR-002",
            "incident_type": "Phishing",
            "severity": "High",
            "containment_steps": [
                "Quarantine reported phishing emails.",
                "Reset affected user credentials and enforce MFA reset.",
                "Block malicious sender domains and URLs.",
            ],
            "communication_template": {
                "internal_msg": "Phishing activity identified. Do not click suspicious links and report unusual emails immediately.",
                "external_msg": "Our team is responding to suspicious email activity and applying preventive measures.",
            },
            "mitigation_steps": [
                "Review mailbox access logs for compromise signs.",
                "Run endpoint scans for payload execution.",
                "Provide targeted user awareness follow-up.",
            ],
            "post_incident_checklist": [
                "Measure click and report rates.",
                "Tune email filtering and impersonation controls.",
                "Update awareness training content.",
            ],
            "estimated_recovery_hours": 12,
        },
        {
            "id": "IR-003",
            "incident_type": "Data Breach",
            "severity": "Critical",
            "containment_steps": [
                "Disable unauthorized data access channels.",
                "Preserve logs and forensic snapshots.",
                "Engage legal and compliance stakeholders.",
            ],
            "communication_template": {
                "internal_msg": "Potential data breach under investigation. Preserve evidence and route all inquiries to incident lead.",
                "external_msg": "We are assessing a potential data security event and will provide updates as verified information becomes available.",
            },
            "mitigation_steps": [
                "Confirm affected datasets and scope.",
                "Revoke exposed credentials and tokens.",
                "Implement additional monitoring and DLP controls.",
            ],
            "post_incident_checklist": [
                "Perform mandatory notifications as required.",
                "Track remediation completion and validation.",
                "Update breach response procedures.",
            ],
            "estimated_recovery_hours": 72,
        },
    ]


def get_recovery_plans() -> List[RecoveryPlan]:
    """Return recovery and continuity plan templates."""
    return [
        {
            "id": "RC-001",
            "name": "Critical Systems Daily Backup Plan",
            "backup_type": "Automated",
            "backup_frequency": "Daily",
            "encryption": True,
            "offsite": True,
            "rto_hours": 8,
            "rpo_hours": 4,
            "testing_schedule": "Quarterly restore drill",
            "steps": [
                "Verify backup job success and integrity logs.",
                "Restore priority systems in predefined order.",
                "Validate data consistency with business owners.",
            ],
        },
        {
            "id": "RC-002",
            "name": "Core Database Replication Plan",
            "backup_type": "Automated",
            "backup_frequency": "Hourly snapshots",
            "encryption": True,
            "offsite": True,
            "rto_hours": 4,
            "rpo_hours": 1,
            "testing_schedule": "Monthly failover simulation",
            "steps": [
                "Promote standby database instance.",
                "Re-point applications to failover endpoint.",
                "Run validation queries and service checks.",
            ],
        },
        {
            "id": "RC-003",
            "name": "Manual Emergency Operations Plan",
            "backup_type": "Manual",
            "backup_frequency": "Weekly",
            "encryption": False,
            "offsite": False,
            "rto_hours": 24,
            "rpo_hours": 12,
            "testing_schedule": "Semi-annual tabletop exercise",
            "steps": [
                "Activate manual order and billing fallback process.",
                "Capture transactions for later reconciliation.",
                "Resume normal operations after system verification.",
            ],
        },
    ]


class IncidentTracker:
    """Track incident lifecycle from detection to resolution."""

    def __init__(self) -> None:
        self._incidents: List[IncidentRecord] = []

    def log_incident(self, incident_type: str, severity: str, description: str) -> IncidentRecord:
        """Create and store a new incident record."""
        now = datetime.now(timezone.utc).isoformat()
        incident_id = f"INC-{len(self._incidents) + 1:04d}"
        incident: IncidentRecord = {
            "incident_id": incident_id,
            "incident_type": incident_type,
            "severity": severity,  # Type intentionally broad for practical usage.
            "description": description,
            "status": "Detected",
            "created_at": now,
            "updated_at": now,
        }
        self._incidents.append(incident)
        return incident

    def update_status(self, incident_id: str, status: IncidentStatus) -> Dict[str, str]:
        """Update status for an incident ID."""
        for incident in self._incidents:
            if incident["incident_id"] == incident_id:
                incident["status"] = status
                incident["updated_at"] = datetime.now(timezone.utc).isoformat()
                return {"incident_id": incident_id, "status": status, "updated": "true"}
        return {"incident_id": incident_id, "status": "NotFound", "updated": "false"}

    def get_recovery_progress(self, incident_id: str) -> Dict[str, object]:
        """Return status and completion percentage for recovery workflow."""
        status_to_progress = {
            "Detected": 10,
            "Contained": 40,
            "Recovering": 75,
            "Resolved": 100,
        }
        for incident in self._incidents:
            if incident["incident_id"] == incident_id:
                status = incident["status"]
                return {
                    "incident_id": incident_id,
                    "status": status,
                    "progress_percent": status_to_progress.get(status, 0),
                }
        return {"incident_id": incident_id, "status": "NotFound", "progress_percent": 0}

    def get_all_incidents(self) -> List[IncidentRecord]:
        """Return all incidents tracked in memory."""
        return list(self._incidents)
