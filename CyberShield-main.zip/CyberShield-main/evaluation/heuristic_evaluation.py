from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List

import sys

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))


def evaluate_heuristics() -> Dict[str, List[Dict[str, object]]]:
    rows = [
        {
            "heuristic": "Visibility of system status",
            "score": 4,
            "justification": "Dashboard surfaces risk score, control coverage, incidents, and maturity in real-time visual cards/charts.",
        },
        {
            "heuristic": "Match between system and real world",
            "score": 4,
            "justification": "Terminology uses SME-friendly concepts (assets, controls, incidents, recovery) aligned to practical workflows.",
        },
        {
            "heuristic": "User control and freedom",
            "score": 3,
            "justification": "Users can switch scenarios and update controls/incidents, but dedicated undo/history controls are limited.",
        },
        {
            "heuristic": "Consistency and standards",
            "score": 4,
            "justification": "Consistent NIST module structure, severity colors, and repeated patterns across pages and widgets.",
        },
        {
            "heuristic": "Error prevention",
            "score": 3,
            "justification": "Forms constrain key inputs via select boxes and ranges; additional validation prompts could be expanded.",
        },
    ]
    return {"heuristics": rows}


def print_summary(payload: Dict[str, List[Dict[str, object]]]) -> None:
    print("\nNielsen Heuristic Evaluation")
    print("-" * 90)
    print("Heuristic".ljust(42) + "Score".ljust(8) + "Justification")
    print("-" * 90)
    for row in payload["heuristics"]:
        print(f"{row['heuristic'][:40].ljust(42)}{str(row['score']).ljust(8)}{row['justification']}")
    avg = sum(int(row["score"]) for row in payload["heuristics"]) / len(payload["heuristics"])
    print("-" * 90)
    print(f"Average Score: {avg:.2f}/5.00")


def main() -> None:
    payload = evaluate_heuristics()
    print_summary(payload)
    output_path = Path("evaluation/heuristics.json")
    output_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"Saved: {output_path}")


if __name__ == "__main__":
    main()
