#!/usr/bin/env bash
set -euo pipefail

echo "== SME CyberShield Validation Runner =="

echo "[1/4] Running pytest with coverage..."
pytest --cov=. --cov-report=term-missing --cov-report=json:coverage.json | tee pytest_output.txt

echo "[2/4] Running scenario evaluation..."
python evaluation/scenario_results.py | tee scenario_eval_output.txt

echo "[3/4] Running heuristic evaluation..."
python evaluation/heuristic_evaluation.py | tee heuristic_eval_output.txt

echo "[4/4] Running NIST benchmark comparison..."
python evaluation/benchmark_comparison.py | tee benchmark_eval_output.txt

python - <<'PY'
import json
import re
import sys
from pathlib import Path

targets_ok = True

coverage_data = json.loads(Path("coverage.json").read_text(encoding="utf-8"))
coverage_pct = float(coverage_data.get("totals", {}).get("percent_covered", 0.0))

pytest_text = Path("pytest_output.txt").read_text(encoding="utf-8")
summary_match = re.search(r"(\d+)\s+passed", pytest_text)
passed_tests = int(summary_match.group(1)) if summary_match else 0

results_payload = json.loads(Path("evaluation/results.json").read_text(encoding="utf-8"))
rows = results_payload["results"]

def row_ok(row):
    rr = row["simulated_risk_reduction_percent"]
    return (
        row["asset_coverage_percent"] >= 80
        and row["control_coverage_percent"] >= 75
        and 20 <= rr <= 30
        and row["nist_maturity_average"] >= 3.0
        and row["rto_met"] is True
        and row["plan_coverage_percent"] >= 75
    )

scenario_ok = all(row_ok(r) for r in rows)
if coverage_pct < 85.0:
    targets_ok = False
if not scenario_ok:
    targets_ok = False

print("\n== Final Summary ==")
print(f"Tests passed: {passed_tests}")
print(f"Coverage %: {coverage_pct:.2f}")
print(f"Scenario metric targets met: {scenario_ok}")

sys.exit(0 if targets_ok else 1)
PY
