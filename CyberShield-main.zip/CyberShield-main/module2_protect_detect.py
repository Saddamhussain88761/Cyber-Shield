"""Module 2 - Protect & Detect."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import List

from data_schemas import DetectionAlert, DetectionMechanism, ProtectiveControl


def get_protective_controls() -> List[ProtectiveControl]:
    """Return baseline protective controls for SME cyber resilience."""
    return [
        {
            "id": "PR-001",
            "name": "Multi-Factor Authentication (MFA) Enforcement",
            "category": "Access Control",
            "nist_function": "Protect",
            "cost_level": "Medium",
            "complexity": "Medium",
            "impact": "High",
            "implemented": True,
            "description": "Require MFA for admin, remote access, and cloud accounts.",
            "checklist_items": [
                "Enable MFA for privileged users.",
                "Enforce MFA for VPN and SaaS applications.",
                "Disable legacy auth protocols where possible.",
            ],
        },
        {
            "id": "PR-002",
            "name": "Automated Patch Management",
            "category": "Platform Security",
            "nist_function": "Protect",
            "cost_level": "Medium",
            "complexity": "Low",
            "impact": "High",
            "implemented": True,
            "description": "Automate OS and application patching to reduce exposure windows.",
            "checklist_items": [
                "Define patch windows per business unit.",
                "Auto-deploy critical patches within SLA.",
                "Track patch exceptions and risk acceptance.",
            ],
        },
        {
            "id": "PR-003",
            "name": "Data Encryption (At Rest and In Transit)",
            "category": "Data Protection",
            "nist_function": "Protect",
            "cost_level": "Medium",
            "complexity": "Medium",
            "impact": "High",
            "implemented": True,
            "description": "Encrypt customer and payment data across storage and transport layers.",
            "checklist_items": [
                "Enable TLS for all external and internal APIs.",
                "Encrypt database backups.",
                "Rotate encryption keys annually or on compromise.",
            ],
        },
        {
            "id": "PR-004",
            "name": "Endpoint Antivirus/EDR",
            "category": "Platform Security",
            "nist_function": "Protect",
            "cost_level": "Low",
            "complexity": "Low",
            "impact": "High",
            "implemented": True,
            "description": "Deploy managed antivirus/EDR on all endpoints and POS terminals.",
            "checklist_items": [
                "Install agent on all managed endpoints.",
                "Enable real-time scanning and tamper protection.",
                "Review daily malware detections.",
            ],
        },
        {
            "id": "PR-005",
            "name": "Security Awareness and Phishing Training",
            "category": "Awareness",
            "nist_function": "Protect",
            "cost_level": "Low",
            "complexity": "Low",
            "impact": "Medium",
            "implemented": False,
            "description": "Train staff to identify phishing, social engineering, and unsafe handling.",
            "checklist_items": [
                "Run quarterly training sessions.",
                "Conduct monthly phishing simulations.",
                "Track click-rate trends and targeted coaching.",
            ],
        },
        {
            "id": "PR-006",
            "name": "Centralized Log Monitoring",
            "category": "Platform Security",
            "nist_function": "Protect",
            "cost_level": "Medium",
            "complexity": "Medium",
            "impact": "Medium",
            "implemented": True,
            "description": "Collect and retain logs for auth, endpoint, and network events.",
            "checklist_items": [
                "Send key system logs to central store.",
                "Set retention and integrity protections.",
                "Define alerting for suspicious patterns.",
            ],
        },
        {
            "id": "PR-007",
            "name": "Behavioral Anomaly Detection",
            "category": "Platform Security",
            "nist_function": "Protect",
            "cost_level": "High",
            "complexity": "High",
            "impact": "High",
            "implemented": False,
            "description": "Use anomaly analytics to detect unusual account and network activity.",
            "checklist_items": [
                "Define normal baseline behavior.",
                "Tune model to reduce false positives.",
                "Integrate alerts into incident response workflow.",
            ],
        },
    ]


def get_detection_mechanisms() -> List[DetectionMechanism]:
    """Return detection rules and response mappings."""
    return [
        {
            "id": "DE-001",
            "name": "Excessive Failed Login Attempts",
            "indicator_type": "Login",
            "severity": "High",
            "description": "Detect brute-force attempts on privileged or remote accounts.",
            "alert_threshold": "10 failed attempts in 5 minutes per account",
            "response_action": "Temporarily lock account and trigger SOC review.",
        },
        {
            "id": "DE-002",
            "name": "Unusual Outbound Data Transfer",
            "indicator_type": "Network",
            "severity": "Critical",
            "description": "Identify possible data exfiltration by volume or destination anomaly.",
            "alert_threshold": "> 500MB transfer to untrusted domain in 15 minutes",
            "response_action": "Block connection and isolate affected host.",
        },
        {
            "id": "DE-003",
            "name": "Endpoint Ransomware Behavior",
            "indicator_type": "Endpoint",
            "severity": "Critical",
            "description": "Detect rapid file encryption patterns and suspicious process chains.",
            "alert_threshold": "Mass file rename/encryption behavior across user directories",
            "response_action": "Kill process, isolate endpoint, and launch ransomware playbook.",
        },
        {
            "id": "DE-004",
            "name": "Suspicious Email Attachment Activity",
            "indicator_type": "Email",
            "severity": "Medium",
            "description": "Detect macro-enabled or executable attachment delivery spikes.",
            "alert_threshold": "5 malicious attachment detections in 30 minutes",
            "response_action": "Quarantine messages and notify users.",
        },
        {
            "id": "DE-005",
            "name": "Repeated Vulnerability Scan Findings",
            "indicator_type": "Endpoint",
            "severity": "High",
            "description": "Identify unresolved critical vulnerabilities recurring across scans.",
            "alert_threshold": "Same critical CVE present in 3 consecutive scans",
            "response_action": "Escalate to patch management owner with remediation SLA.",
        },
    ]


def calculate_control_coverage(controls: List[ProtectiveControl]) -> float:
    """Return implemented control percentage."""
    if not controls:
        return 0.0
    implemented = sum(1 for control in controls if control["implemented"])
    return round((implemented / len(controls)) * 100, 2)


def simulate_detection_event(event_type: str) -> DetectionAlert:
    """Simulate a detection alert based on event category."""
    event_key = event_type.strip().lower()
    mapped_events = {
        "login": ("High", "Multiple failed logins detected for admin account."),
        "network": ("Critical", "Abnormal outbound traffic suggests possible exfiltration."),
        "endpoint": ("Critical", "Ransomware-like process behavior observed on endpoint."),
        "email": ("Medium", "Phishing campaign pattern detected in inbound mail."),
    }
    severity, description = mapped_events.get(
        event_key,
        ("Low", "General suspicious activity detected; manual triage recommended."),
    )
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event_type": event_type,
        "severity": severity,
        "description": description,
        "recommended_action": "Validate alert context and follow incident response runbook.",
    }
