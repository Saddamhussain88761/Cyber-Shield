"""Main entry point for SME CyberShield Streamlit app."""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any, Dict

import plotly.graph_objects as go
import streamlit as st

from utils.state import ensure_session_state, rebuild_derived_state

st.set_page_config(page_title="SME CyberShield", layout="wide")


def _load_css() -> None:
    css_path = Path("assets/style.css")
    if css_path.exists():
        st.markdown(f"<style>{css_path.read_text(encoding='utf-8')}</style>", unsafe_allow_html=True)


def _scenario_label_to_key(label: str) -> str:
    mapping = {
        "Retail (Ransomware)": "retail_ransomware",
        "Services (Phishing)": "services_phishing",
        "Manufacturing (Breach)": "manufacturing_breach",
    }
    return mapping[label]


def _rebuild_derived_state() -> None:
    rebuild_derived_state()


def _initialize_state() -> None:
    ensure_session_state()


def _handle_scenario_change(next_key: str) -> None:
    if st.session_state.selected_scenario_key != next_key:
        st.session_state.selected_scenario_key = next_key
        st.session_state.current_data = deepcopy(st.session_state.all_scenarios[next_key])
        st.session_state.incidents = []
        st.session_state.policy_checks = {}
        _rebuild_derived_state()
        st.session_state.baseline_summary = deepcopy(st.session_state.current_data["summary"])
        st.session_state.baseline_coverage = st.session_state.current_data["control_coverage"]


def _render_nist_wheel() -> None:
    labels = ["Govern", "Identify", "Protect", "Detect", "Respond", "Recover"]
    values = [1, 1, 1, 1, 1, 1]
    colors = ["#264653", "#2a9d8f", "#457b9d", "#8d99ae", "#f4a261", "#e76f51"]
    fig = go.Figure(
        data=[
            go.Pie(
                labels=labels,
                values=values,
                hole=0.45,
                marker=dict(colors=colors),
                textinfo="label",
                sort=False,
            )
        ]
    )
    fig.update_layout(title="NIST CSF 2.0 Functions Wheel", margin=dict(l=20, r=20, t=50, b=20))
    st.plotly_chart(fig, use_container_width=True)


_load_css()
_initialize_state()

st.sidebar.title("SME CyberShield")
st.sidebar.markdown("Cybersecurity Risk Management for SMEs")

scenario_label = st.sidebar.selectbox(
    "Select Scenario",
    ["Retail (Ransomware)", "Services (Phishing)", "Manufacturing (Breach)"],
    index=["retail_ransomware", "services_phishing", "manufacturing_breach"].index(
        st.session_state.selected_scenario_key
    ),
)
_handle_scenario_change(_scenario_label_to_key(scenario_label))

data: Dict[str, Any] = st.session_state.current_data
active_incidents = sum(1 for item in st.session_state.incidents if item.get("status") != "Resolved")

st.title("SME CyberShield Overview")
st.markdown(
    """
This multi-page dashboard implements NIST CSF 2.0 and ISO 27005 aligned workflows for
SME risk governance, control monitoring, incident response, and executive reporting.
"""
)

team_cols = st.columns(4)
team_cols[0].info("**Sher Dil Awan**  \nGovern & Identify")
team_cols[1].info("**Faizan Javed**  \nProtect & Detect")
team_cols[2].info("**Ali Shan**  \nRespond & Recover")
team_cols[3].info("**Saddam Hussain**  \nIntegration & Dashboard")

left, right = st.columns([1.2, 1])
with left:
    _render_nist_wheel()
with right:
    c1, c2 = st.columns(2)
    c1.metric("Total Assets", data["summary"]["total_assets"])
    c2.metric("Overall Risk Score", data["summary"]["overall_risk_score"])
    c3, c4 = st.columns(2)
    c3.metric("Control Coverage %", data["control_coverage"])
    c4.metric("Active Incidents", active_incidents)

st.caption("Use the page navigator in the left sidebar to explore each NIST function area.")
