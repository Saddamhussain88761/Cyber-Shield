$ErrorActionPreference = "Stop"

Write-Host "== SME CyberShield Validation Runner (PowerShell) =="

Write-Host "[1/4] Running pytest with coverage..."
python -m pytest --cov=. --cov-config=.coveragerc --cov-report=term-missing --cov-report=json:coverage.json | Tee-Object -FilePath pytest_output.txt

Write-Host "[2/4] Running scenario evaluation..."
python evaluation/scenario_results.py | Tee-Object -FilePath scenario_eval_output.txt

Write-Host "[3/4] Running heuristic evaluation..."
python evaluation/heuristic_evaluation.py | Tee-Object -FilePath heuristic_eval_output.txt

Write-Host "[4/4] Running NIST benchmark comparison..."
python evaluation/benchmark_comparison.py | Tee-Object -FilePath benchmark_eval_output.txt

$coverageJson = Get-Content coverage.json -Raw | ConvertFrom-Json
$coveragePct = [double]$coverageJson.totals.percent_covered

$pytestText = Get-Content pytest_output.txt -Raw
$passedTests = 0
if ($pytestText -match "(\d+)\s+passed") { $passedTests = [int]$matches[1] }

$resultsPayload = Get-Content evaluation/results.json -Raw | ConvertFrom-Json
$rows = $resultsPayload.results

$scenarioOk = $true
foreach ($row in $rows) {
    $rr = [double]$row.simulated_risk_reduction_percent
    $ok = (
        [double]$row.asset_coverage_percent -ge 80 -and
        [double]$row.control_coverage_percent -ge 75 -and
        $rr -ge 20 -and $rr -le 30 -and
        [double]$row.nist_maturity_average -ge 3.0 -and
        [bool]$row.rto_met -eq $true -and
        [double]$row.plan_coverage_percent -ge 75
    )
    if (-not $ok) { $scenarioOk = $false }
}

$targetsOk = ($coveragePct -ge 85.0) -and $scenarioOk

Write-Host "`n== Final Summary =="
Write-Host ("Tests passed: {0}" -f $passedTests)
Write-Host ("Coverage %: {0:N2}" -f $coveragePct)
Write-Host ("Scenario metric targets met: {0}" -f $scenarioOk)

if ($targetsOk) { exit 0 } else { exit 1 }
