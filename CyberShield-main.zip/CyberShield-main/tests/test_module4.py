from __future__ import annotations

from module1_govern_identify import generate_risk_register, get_asset_inventory, get_governance_policies
from module2_protect_detect import get_protective_controls
from module3_respond_recover import get_incident_playbooks
from module4_integration import (
    aggregate_risk_data,
    calculate_nist_maturity,
    generate_full_report,
    generate_risk_heatmap_data,
    run_sme_scenario,
)


def test_aggregate_risk_data_score_range(assets):
    register = generate_risk_register(assets)
    summary = aggregate_risk_data(register)
    assert 0 <= summary["overall_risk_score"] <= 100


def test_nist_maturity_has_all_functions(controls, playbooks, policies, assets):
    scores = calculate_nist_maturity(controls, playbooks, policies, assets)
    assert set(scores.keys()) == {"Govern", "Identify", "Protect", "Detect", "Respond", "Recover"}


def test_nist_maturity_score_range(controls, playbooks, policies, assets):
    scores = calculate_nist_maturity(controls, playbooks, policies, assets)
    assert all(0 <= value <= 5 for value in scores.values())


def test_heatmap_returns_5x5(risk_register):
    matrix = generate_risk_heatmap_data(risk_register)
    assert len(matrix) == 5
    assert all(len(row) == 5 for row in matrix)


def test_run_retail_ransomware():
    result = run_sme_scenario("retail_ransomware")
    assert "summary" in result


def test_run_services_phishing():
    result = run_sme_scenario("services_phishing")
    assert "summary" in result


def test_run_manufacturing_breach():
    result = run_sme_scenario("manufacturing_breach")
    assert "summary" in result


def test_generate_full_report_exportable_dict():
    assets = get_asset_inventory()
    controls = get_protective_controls()
    policies = get_governance_policies()
    playbooks = get_incident_playbooks()
    register = generate_risk_register(assets)
    payload = {
        "company_profile": {"name": "Test SME", "sector": "Retail"},
        "assets": assets,
        "controls": controls,
        "policies": policies,
        "playbooks": playbooks,
        "recovery_plans": [],
        "detection_mechanisms": [],
        "risk_register": register,
        "maturity_scores": calculate_nist_maturity(controls, playbooks, policies, assets),
        "heatmap": generate_risk_heatmap_data(register),
    }
    report = generate_full_report(payload)
    assert isinstance(report, dict)
    assert "metadata" in report
    assert "executive_summary" in report
