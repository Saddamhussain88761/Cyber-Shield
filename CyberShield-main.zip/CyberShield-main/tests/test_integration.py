from __future__ import annotations

from copy import deepcopy

from module1_govern_identify import generate_risk_register
from module2_protect_detect import calculate_control_coverage
from module3_respond_recover import IncidentTracker
from module4_integration import calculate_nist_maturity, run_sme_scenario
from sample_data import get_sme_scenarios


def test_scenarios_produce_different_risk_scores():
    retail = run_sme_scenario("retail_ransomware")["summary"]["overall_risk_score"]
    services = run_sme_scenario("services_phishing")["summary"]["overall_risk_score"]
    manufacturing = run_sme_scenario("manufacturing_breach")["summary"]["overall_risk_score"]
    assert len({retail, services, manufacturing}) > 1


def test_control_coverage_increases_when_controls_implemented(controls):
    before = calculate_control_coverage(controls)
    for control in controls:
        control["implemented"] = True
    after = calculate_control_coverage(controls)
    assert after >= before
    assert after == 100


def test_incident_resolved_progress_reaches_100():
    tracker = IncidentTracker()
    incident = tracker.log_incident("Phishing", "High", "Credential theft attempt")
    tracker.update_status(incident["incident_id"], "Resolved")
    progress = tracker.get_recovery_progress(incident["incident_id"])
    assert progress["progress_percent"] == 100


def test_maturity_improves_when_all_controls_implemented(scenarios):
    data = deepcopy(scenarios["retail_ransomware"])
    before = calculate_nist_maturity(data["controls"], data["playbooks"], data["policies"], data["assets"])
    for control in data["controls"]:
        control["implemented"] = True
    after = calculate_nist_maturity(data["controls"], data["playbooks"], data["policies"], data["assets"])
    assert after["Protect"] >= before["Protect"]
    assert after["Detect"] >= before["Detect"]


def test_generated_report_contains_required_sections():
    result = run_sme_scenario("retail_ransomware")
    report = result["report"]
    assert "metadata" in report
    assert "organization" in report
    assert "executive_summary" in report
    assert "detailed_sections" in report
    assert "risk_register" in report["detailed_sections"]
