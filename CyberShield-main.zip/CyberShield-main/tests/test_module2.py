from __future__ import annotations

from module2_protect_detect import (
    calculate_control_coverage,
    get_detection_mechanisms,
    get_protective_controls,
    simulate_detection_event,
)


def test_protective_controls_required_categories():
    controls = get_protective_controls()
    categories = {c["category"] for c in controls}
    assert {"Access Control", "Data Protection", "Platform Security", "Awareness"}.issubset(categories)


def test_control_coverage_empty_list():
    assert calculate_control_coverage([]) == 0


def test_control_coverage_all_implemented():
    controls = get_protective_controls()
    for control in controls:
        control["implemented"] = True
    assert calculate_control_coverage(controls) == 100


def test_control_coverage_range(controls):
    coverage = calculate_control_coverage(controls)
    assert 0 <= coverage <= 100


def test_simulate_detection_event_login_anomaly_fields():
    alert = simulate_detection_event("login_anomaly")
    assert isinstance(alert, dict)
    assert "timestamp" in alert
    assert "severity" in alert
    assert "recommended_action" in alert


def test_mfa_control_exists_in_access_control():
    controls = get_protective_controls()
    mfa_controls = [c for c in controls if "mfa" in c["name"].lower() or "multi-factor" in c["name"].lower()]
    assert mfa_controls
    assert any(c["category"] == "Access Control" for c in mfa_controls)


def test_detection_mechanisms_count():
    mechanisms = get_detection_mechanisms()
    assert len(mechanisms) >= 5
