from __future__ import annotations

from copy import deepcopy

import pytest

from module1_govern_identify import (
    generate_risk_register,
    get_asset_inventory,
    get_governance_policies,
)
from module2_protect_detect import get_detection_mechanisms, get_protective_controls
from module3_respond_recover import IncidentTracker, get_incident_playbooks, get_recovery_plans
from sample_data import get_sme_scenarios


@pytest.fixture
def assets():
    return deepcopy(get_asset_inventory())


@pytest.fixture
def policies():
    return deepcopy(get_governance_policies())


@pytest.fixture
def controls():
    return deepcopy(get_protective_controls())


@pytest.fixture
def mechanisms():
    return deepcopy(get_detection_mechanisms())


@pytest.fixture
def playbooks():
    return deepcopy(get_incident_playbooks())


@pytest.fixture
def recovery_plans():
    return deepcopy(get_recovery_plans())


@pytest.fixture
def risk_register(assets):
    return generate_risk_register(assets)


@pytest.fixture
def tracker():
    return IncidentTracker()


@pytest.fixture
def scenarios():
    return deepcopy(get_sme_scenarios())
