from __future__ import annotations

from module3_respond_recover import IncidentTracker, get_incident_playbooks, get_recovery_plans


def test_playbooks_include_ransomware():
    playbooks = get_incident_playbooks()
    incident_types = {p["incident_type"] for p in playbooks}
    assert "Ransomware" in incident_types


def test_playbooks_containment_steps_non_empty(playbooks):
    for playbook in playbooks:
        assert isinstance(playbook["containment_steps"], list)
        assert len(playbook["containment_steps"]) > 0


def test_log_incident_sets_detected_status():
    tracker = IncidentTracker()
    incident = tracker.log_incident("Phishing", "High", "Suspicious email campaign")
    assert incident["status"] == "Detected"


def test_update_status_changes_status():
    tracker = IncidentTracker()
    incident = tracker.log_incident("Ransomware", "Critical", "Mass encryption pattern")
    result = tracker.update_status(incident["incident_id"], "Contained")
    assert result["updated"] == "true"
    all_incidents = tracker.get_all_incidents()
    assert all_incidents[0]["status"] == "Contained"


def test_get_recovery_progress_range():
    tracker = IncidentTracker()
    incident = tracker.log_incident("Data Breach", "Critical", "Potential data exfiltration")
    progress = tracker.get_recovery_progress(incident["incident_id"])
    assert 0 <= progress["progress_percent"] <= 100


def test_recovery_plans_have_rto_rpo(recovery_plans):
    for plan in recovery_plans:
        assert "rto_hours" in plan
        assert "rpo_hours" in plan
        assert plan["rto_hours"] >= 0
        assert plan["rpo_hours"] >= 0


def test_ransomware_playbook_recovery_hours_defined():
    playbooks = get_incident_playbooks()
    ransomware = next((p for p in playbooks if p["incident_type"] == "Ransomware"), None)
    assert ransomware is not None
    assert ransomware["estimated_recovery_hours"] > 0
