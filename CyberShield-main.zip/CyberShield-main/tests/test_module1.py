from __future__ import annotations

from module1_govern_identify import (
    calculate_risk_score,
    generate_risk_register,
    get_asset_inventory,
    get_governance_policies,
)


def test_asset_inventory_non_empty():
    assets = get_asset_inventory()
    assert isinstance(assets, list)
    assert len(assets) > 0


def test_asset_required_fields(assets):
    required = {"id", "name", "type", "owner", "vulnerabilities", "criticality"}
    for asset in assets:
        assert required.issubset(asset.keys())


def test_calculate_risk_score_critical():
    score, label = calculate_risk_score(5, 5)
    assert score == 25
    assert label == "Critical"


def test_calculate_risk_score_low():
    score, label = calculate_risk_score(1, 1)
    assert score == 1
    assert label == "Low"


def test_calculate_risk_score_range():
    for likelihood in range(1, 6):
        for impact in range(1, 6):
            score, _ = calculate_risk_score(likelihood, impact)
            assert 1 <= score <= 25


def test_risk_register_row_per_asset(assets):
    register = generate_risk_register(assets)
    assert len(register) == len(assets)


def test_risk_register_required_fields(risk_register):
    required = {
        "asset_id",
        "threat",
        "likelihood",
        "impact",
        "risk_score",
        "risk_level",
        "recommended_control",
    }
    for row in risk_register:
        assert required.issubset(row.keys())


def test_high_criticality_average_risk_higher_than_low(assets):
    # Ensure low criticality samples exist for this assertion.
    assets_with_low = list(assets)
    assets_with_low.append(
        {
            "id": "AST-LOW-1",
            "name": "Archive Kiosk",
            "type": "Hardware",
            "owner": "Admin",
            "vulnerabilities": ["Minor local config drift"],
            "criticality": "Low",
        }
    )
    assets_with_low.append(
        {
            "id": "AST-LOW-2",
            "name": "Public Brochure Site",
            "type": "Software",
            "owner": "Marketing",
            "vulnerabilities": [],
            "criticality": "Low",
        }
    )
    register = generate_risk_register(assets_with_low)
    critical_map = {asset["id"]: asset["criticality"] for asset in assets_with_low}
    high_scores = [row["risk_score"] for row in register if critical_map[row["asset_id"]] == "High"]
    low_scores = [row["risk_score"] for row in register if critical_map[row["asset_id"]] == "Low"]
    assert high_scores and low_scores
    assert (sum(high_scores) / len(high_scores)) > (sum(low_scores) / len(low_scores))


def test_governance_policies_minimum_count():
    policies = get_governance_policies()
    assert len(policies) >= 5
