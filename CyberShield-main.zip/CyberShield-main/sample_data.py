"""Sample SME scenarios used by integration and dashboard layers."""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict

from module1_govern_identify import get_asset_inventory, get_governance_policies
from module2_protect_detect import get_detection_mechanisms, get_protective_controls
from module3_respond_recover import get_incident_playbooks, get_recovery_plans


def get_sme_scenarios() -> Dict[str, Dict[str, Any]]:
    """Return 3 complete SME scenarios with realistic posture differences."""
    base_assets = get_asset_inventory()
    base_controls = get_protective_controls()
    base_policies = get_governance_policies()
    base_playbooks = get_incident_playbooks()
    base_recovery = get_recovery_plans()
    base_detection = get_detection_mechanisms()

    retail_assets = deepcopy(base_assets)
    retail_assets[0]["vulnerabilities"].append("Shared POS admin account")
    retail_assets[2]["vulnerabilities"].append("Sensitive exports stored unencrypted")

    services_assets = deepcopy(base_assets)
    services_assets[6]["criticality"] = "High"
    services_assets[6]["vulnerabilities"].append("No DMARC enforcement")

    manufacturing_assets = deepcopy(base_assets)
    manufacturing_assets.append(
        {
            "id": "AST-009",
            "name": "Factory OT Monitoring Server",
            "type": "Hardware",
            "owner": "Plant Operations Manager",
            "vulnerabilities": ["Legacy OS", "Flat network exposure"],
            "criticality": "High",
        }
    )

    retail_controls = deepcopy(base_controls)
    retail_controls[4]["implemented"] = True
    retail_controls[6]["implemented"] = False

    services_controls = deepcopy(base_controls)
    services_controls[4]["implemented"] = True
    services_controls[6]["implemented"] = False

    manufacturing_controls = deepcopy(base_controls)
    manufacturing_controls[1]["implemented"] = True
    manufacturing_controls[4]["implemented"] = True
    manufacturing_controls[6]["implemented"] = False

    return {
        "retail_ransomware": {
            "company_profile": {
                "name": "Sher Dil Retail SME",
                "sector": "Retail",
                "employees": 120,
                "scenario_focus": "Ransomware disruption across POS and back-office systems.",
            },
            "assets": retail_assets,
            "policies": deepcopy(base_policies),
            "controls": retail_controls,
            "detection_mechanisms": deepcopy(base_detection),
            "playbooks": deepcopy(base_playbooks),
            "recovery_plans": deepcopy(base_recovery),
        },
        "services_phishing": {
            "company_profile": {
                "name": "Faizan Advisory Services",
                "sector": "Professional Services",
                "employees": 80,
                "scenario_focus": "Phishing-led credential theft risk in client-facing teams.",
            },
            "assets": services_assets,
            "policies": deepcopy(base_policies),
            "controls": services_controls,
            "detection_mechanisms": deepcopy(base_detection),
            "playbooks": deepcopy(base_playbooks),
            "recovery_plans": deepcopy(base_recovery),
        },
        "manufacturing_breach": {
            "company_profile": {
                "name": "Ali Shan Components Ltd.",
                "sector": "Manufacturing",
                "employees": 240,
                "scenario_focus": "Data breach and OT disruption from weak network segmentation.",
            },
            "assets": manufacturing_assets,
            "policies": deepcopy(base_policies),
            "controls": manufacturing_controls,
            "detection_mechanisms": deepcopy(base_detection),
            "playbooks": deepcopy(base_playbooks),
            "recovery_plans": deepcopy(base_recovery),
        },
    }


def get_scenario_data(scenario_name: str) -> Dict[str, Any]:
    """Fetch one scenario by name."""
    scenarios = get_sme_scenarios()
    if scenario_name not in scenarios:
        allowed = ", ".join(scenarios.keys())
        raise ValueError(f"Unknown scenario '{scenario_name}'. Allowed: {allowed}")
    return scenarios[scenario_name]
