"""Module 4 - Integration & Dashboard Setup."""

from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from typing import Any, Dict, List

import pandas as pd

from module1_govern_identify import generate_risk_register
from sample_data import get_scenario_data


def aggregate_risk_data(risk_register: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Summarize risk register statistics for dashboard cards."""
    if not risk_register:
        return {
            "total_assets": 0,
            "critical_risks": 0,
            "high_risks": 0,
            "medium_risks": 0,
            "low_risks": 0,
            "overall_risk_score": 0.0,
            "top_3_threats": [],
        }

    df = pd.DataFrame(risk_register)
    level_counts = df["risk_level"].value_counts().to_dict()
    threat_counts = Counter(df["threat"].tolist()).most_common(3)
    max_possible = len(df) * 25
    normalized = (float(df["risk_score"].sum()) / max_possible) * 100 if max_possible else 0.0

    return {
        "total_assets": int(df["asset_id"].nunique()),
        "critical_risks": int(level_counts.get("Critical", 0)),
        "high_risks": int(level_counts.get("High", 0)),
        "medium_risks": int(level_counts.get("Medium", 0)),
        "low_risks": int(level_counts.get("Low", 0)),
        "overall_risk_score": round(normalized, 2),
        "top_3_threats": [{"threat": threat, "count": count} for threat, count in threat_counts],
    }


def calculate_nist_maturity(
    controls: List[Dict[str, Any]],
    playbooks: List[Dict[str, Any]],
    policies: List[Dict[str, Any]],
    assets: List[Dict[str, Any]],
) -> Dict[str, float]:
    """Estimate maturity scores (0-5) for each NIST CSF function."""
    total_controls = max(1, len(controls))
    implemented_controls = sum(1 for control in controls if control.get("implemented"))
    protect_score = min(5.0, (implemented_controls / total_controls) * 5)

    detection_keywords = ("log", "anomaly", "monitor")
    detect_controls = [
        control
        for control in controls
        if any(word in control.get("name", "").lower() for word in detection_keywords)
    ]
    detect_total = max(1, len(detect_controls))
    detect_done = sum(1 for control in detect_controls if control.get("implemented"))
    detect_score = min(5.0, (detect_done / detect_total) * 5)

    govern_score = min(5.0, (len(policies) / 8) * 5)
    identify_score = min(5.0, (len(assets) / 10) * 5)
    respond_score = min(5.0, (len(playbooks) / 5) * 5)

    recover_ready = sum(
        1
        for playbook in playbooks
        if playbook.get("incident_type") in {"Ransomware", "Data Breach", "Phishing"}
    )
    recover_score = min(5.0, (recover_ready / 3) * 5)

    return {
        "Govern": round(govern_score, 2),
        "Identify": round(identify_score, 2),
        "Protect": round(protect_score, 2),
        "Detect": round(detect_score, 2),
        "Respond": round(respond_score, 2),
        "Recover": round(recover_score, 2),
    }


def generate_risk_heatmap_data(risk_register: List[Dict[str, Any]]) -> List[List[int]]:
    """Build 5x5 likelihood-vs-impact matrix.

    Matrix indexing:
    - Rows => impact 1..5
    - Columns => likelihood 1..5
    """
    matrix = [[0 for _ in range(5)] for _ in range(5)]
    for risk in risk_register:
        likelihood = int(risk.get("likelihood", 1))
        impact = int(risk.get("impact", 1))
        if 1 <= likelihood <= 5 and 1 <= impact <= 5:
            matrix[impact - 1][likelihood - 1] += 1
    return matrix


def generate_full_report(all_data: Dict[str, Any]) -> Dict[str, Any]:
    """Generate a structured report object for JSON/PDF export pipelines."""
    risk_register = all_data.get("risk_register", [])
    summary = aggregate_risk_data(risk_register)
    maturity = all_data.get("maturity_scores", {})
    heatmap = all_data.get("heatmap", [])

    return {
        "metadata": {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "report_version": "1.0",
            "frameworks": ["NIST CSF 2.0", "ISO 27005"],
        },
        "organization": all_data.get("company_profile", {}),
        "executive_summary": {
            "overall_risk_score": summary["overall_risk_score"],
            "top_threats": summary["top_3_threats"],
            "risk_distribution": {
                "critical": summary["critical_risks"],
                "high": summary["high_risks"],
                "medium": summary["medium_risks"],
                "low": summary["low_risks"],
            },
            "nist_maturity": maturity,
        },
        "detailed_sections": {
            "governance_policies": all_data.get("policies", []),
            "asset_inventory": all_data.get("assets", []),
            "risk_register": risk_register,
            "controls": all_data.get("controls", []),
            "detection_mechanisms": all_data.get("detection_mechanisms", []),
            "incident_playbooks": all_data.get("playbooks", []),
            "recovery_plans": all_data.get("recovery_plans", []),
            "risk_heatmap_matrix": heatmap,
        },
    }


def run_sme_scenario(scenario_name: str) -> Dict[str, Any]:
    """Run one of the predefined SME scenarios end-to-end."""
    scenario = get_scenario_data(scenario_name)
    assets = scenario["assets"]
    policies = scenario["policies"]
    controls = scenario["controls"]
    playbooks = scenario["playbooks"]

    risk_register = generate_risk_register(assets)
    summary = aggregate_risk_data(risk_register)
    maturity_scores = calculate_nist_maturity(controls, playbooks, policies, assets)
    heatmap = generate_risk_heatmap_data(risk_register)

    full_payload = {
        **scenario,
        "risk_register": risk_register,
        "summary": summary,
        "maturity_scores": maturity_scores,
        "heatmap": heatmap,
    }
    full_payload["report"] = generate_full_report(full_payload)
    return full_payload
