"""Page 1 - Govern & Identify."""

from __future__ import annotations

from typing import Dict

import pandas as pd
import streamlit as st

from utils.charts import risk_heatmap
from utils.state import ensure_session_state, rebuild_derived_state


def _refresh_data() -> None:
    rebuild_derived_state()


def _criticality_color(value: str) -> str:
    color_map = {
        "High": "background-color: #f4cccc",
        "Medium": "background-color: #fce5cd",
        "Low": "background-color: #d9ead3",
    }
    return color_map.get(value, "")


st.title("Govern & Identify")
data = ensure_session_state()
_refresh_data()

st.subheader("1) Asset Inventory")
asset_df = pd.DataFrame(data["assets"]).copy()
asset_df["vulnerabilities_count"] = asset_df["vulnerabilities"].apply(len)
asset_df = asset_df.rename(
    columns={
        "name": "Name",
        "type": "Type",
        "owner": "Owner",
        "criticality": "Criticality",
        "vulnerabilities_count": "Vulnerabilities count",
    }
)[["Name", "Type", "Owner", "Criticality", "Vulnerabilities count"]]

f1, f2, f3 = st.columns(3)
type_filter = f1.multiselect("Filter Type", sorted(asset_df["Type"].unique()), default=sorted(asset_df["Type"].unique()))
criticality_filter = f2.multiselect(
    "Filter Criticality",
    sorted(asset_df["Criticality"].unique()),
    default=sorted(asset_df["Criticality"].unique()),
)
owner_filter = f3.multiselect("Filter Owner", sorted(asset_df["Owner"].unique()), default=sorted(asset_df["Owner"].unique()))
asset_df = asset_df[
    asset_df["Type"].isin(type_filter)
    & asset_df["Criticality"].isin(criticality_filter)
    & asset_df["Owner"].isin(owner_filter)
]

styled_assets = asset_df.style.map(_criticality_color, subset=["Criticality"])
st.dataframe(styled_assets, width="stretch")

st.subheader("2) Risk Register")
asset_map: Dict[str, str] = {asset["id"]: asset["name"] for asset in data["assets"]}
risk_df = pd.DataFrame(data["risk_register"]).copy()
risk_df["Asset"] = risk_df["asset_id"].map(asset_map)
risk_df = risk_df.rename(
    columns={
        "threat": "Threat",
        "likelihood": "Likelihood (1-5)",
        "impact": "Impact (1-5)",
        "risk_score": "Risk Score",
        "risk_level": "Risk Level",
        "recommended_control": "Recommended Control",
    }
)[
    [
        "Asset",
        "Threat",
        "Likelihood (1-5)",
        "Impact (1-5)",
        "Risk Score",
        "Risk Level",
        "Recommended Control",
    ]
]
filter_level = st.selectbox("Filter by Risk Level", ["All", "Critical", "High", "Medium", "Low"])
threat_filter = st.multiselect("Filter by Threat", sorted(risk_df["Threat"].unique()), default=sorted(risk_df["Threat"].unique()))
if filter_level != "All":
    risk_df = risk_df[risk_df["Risk Level"] == filter_level]
risk_df = risk_df[risk_df["Threat"].isin(threat_filter)]
st.dataframe(risk_df, width="stretch")

st.subheader("3) Risk Heatmap")
st.plotly_chart(risk_heatmap(data["risk_register"]), width="stretch")

st.subheader("4) Governance Policies")
for policy in data["policies"]:
    with st.expander(f"{policy['id']} - {policy['title']}"):
        st.write(policy["description"])
        st.markdown(f"**Owner Role:** {policy['owner_role']}")
        st.markdown(
            "<span class='badge badge-govern'>Govern</span>",
            unsafe_allow_html=True,
        )
        checks = []
        for idx, action in enumerate(policy["checklist"]):
            key = f"policy_{policy['id']}_{idx}"
            checked = st.checkbox(action, key=key, value=st.session_state.policy_checks.get(key, False))
            st.session_state.policy_checks[key] = checked
            checks.append(checked)
        completion = (sum(checks) / len(checks) * 100) if checks else 0
        st.progress(completion / 100)
        st.caption(f"Checklist completion: {completion:.1f}%")
