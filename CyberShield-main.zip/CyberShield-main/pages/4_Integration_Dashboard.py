"""Page 4 - Integration Dashboard."""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, List

import pandas as pd
import plotly.express as px
import streamlit as st

from module1_govern_identify import generate_risk_register
from module2_protect_detect import calculate_control_coverage
from module4_integration import aggregate_risk_data, calculate_nist_maturity
from sample_data import get_sme_scenarios
from utils.charts import nist_radar, scenario_comparison
from utils.export import export_json_bytes, generate_pdf_report
from utils.state import ensure_session_state, rebuild_derived_state


def _refresh_data() -> None:
    rebuild_derived_state()


st.title("Integration Dashboard")
data = ensure_session_state()
_refresh_data()

st.subheader("1) NIST Maturity Radar Chart")
st.plotly_chart(nist_radar(data["maturity_scores"]), width="stretch")

st.subheader("2) Risk Reduction Simulation")
risk_df = pd.DataFrame(data["risk_register"]).copy()
category_map = {
    "Credential compromise via phishing": "Phishing",
    "Exploitation of unpatched systems": "Vulnerability",
    "Unauthorized access to sensitive data": "Data Exposure",
    "Third-party service compromise": "Third-party",
    "Malware infection and lateral movement": "Malware",
}
risk_df["Threat Category"] = risk_df["threat"].map(category_map).fillna("Other")
before = risk_df.groupby("Threat Category", as_index=False)["risk_score"].sum().rename(columns={"risk_score": "Score"})
after = before.copy()
after["Score"] = (after["Score"] * 0.75).round(2)

col1, col2 = st.columns(2)
with col1:
    before_fig = px.bar(before, x="Threat Category", y="Score", title="Before Framework", color_discrete_sequence=["#1f4e79"])
    st.plotly_chart(before_fig, width="stretch")
with col2:
    after_fig = px.bar(after, x="Threat Category", y="Score", title="After Framework", color_discrete_sequence=["#2e8b57"])
    st.plotly_chart(after_fig, width="stretch")

before_total = before["Score"].sum()
after_total = after["Score"].sum()
reduction_pct = ((before_total - after_total) / before_total * 100) if before_total else 0
st.info(f"Simulated risk reduction achieved: **{reduction_pct:.1f}%** (target 20-30%).")

st.subheader("3) Executive Summary Cards")
baseline_summary = st.session_state.baseline_summary
baseline_coverage = st.session_state.baseline_coverage
active_incidents = sum(1 for item in st.session_state.incidents if item.get("status") != "Resolved")

c1, c2, c3, c4 = st.columns(4)
c1.metric(
    "Total Assets",
    data["summary"]["total_assets"],
    delta=data["summary"]["total_assets"] - baseline_summary.get("total_assets", 0),
)
c2.metric(
    "Overall Risk Score",
    data["summary"]["overall_risk_score"],
    delta=round(data["summary"]["overall_risk_score"] - baseline_summary.get("overall_risk_score", 0), 2),
    delta_color="inverse",
)
c3.metric(
    "Control Coverage %",
    data["control_coverage"],
    delta=round(data["control_coverage"] - baseline_coverage, 2),
)
c4.metric("Active Incidents", active_incidents, delta=active_incidents)

st.subheader("4) Scenario Comparison")
scenario_rows: List[Dict[str, Any]] = []
for key, scenario in get_sme_scenarios().items():
    simulated = deepcopy(scenario)
    register = generate_risk_register(simulated["assets"])
    summary = aggregate_risk_data(register)
    coverage = calculate_control_coverage(simulated["controls"])
    maturity = calculate_nist_maturity(
        simulated["controls"], simulated["playbooks"], simulated["policies"], simulated["assets"]
    )
    scenario_rows.append(
        {
            "Scenario": key.replace("_", " ").title(),
            "Risk Score": summary["overall_risk_score"],
            "Control Coverage": coverage,
            "NIST Maturity": round(sum(maturity.values()) / 6, 2),
        }
    )
st.plotly_chart(scenario_comparison(scenario_rows), width="stretch")

st.subheader("5) Export Report")
report_payload = data["report"]
pdf_bytes = generate_pdf_report(report_payload)
json_bytes = export_json_bytes(report_payload)

st.download_button(
    "Generate PDF Report",
    data=pdf_bytes,
    file_name="sme_cybershield_report.pdf",
    mime="application/pdf",
)
st.download_button(
    "Export JSON",
    data=json_bytes,
    file_name="sme_cybershield_report.json",
    mime="application/json",
)
