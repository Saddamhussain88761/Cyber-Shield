"""Page 3 - Respond & Recover."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Dict, List

import pandas as pd
import plotly.express as px
import streamlit as st

from utils.charts import recovery_timeline
from utils.state import ensure_session_state, rebuild_derived_state


def _refresh_data() -> None:
    rebuild_derived_state()


def _next_status(current: str) -> str:
    order = ["Detected", "Contained", "Recovering", "Resolved"]
    if current not in order:
        return "Detected"
    idx = order.index(current)
    return order[min(idx + 1, len(order) - 1)]


st.title("Respond & Recover")
data = ensure_session_state()
_refresh_data()

st.subheader("1) Incident Response Playbooks")
for playbook in data["playbooks"]:
    with st.expander(f"{playbook['incident_type']} Playbook ({playbook['severity']})"):
        severity_class = f"badge-{playbook['severity'].lower()}"
        st.markdown(
            f"<span class='badge {severity_class}'>{playbook['severity']}</span>",
            unsafe_allow_html=True,
        )
        st.write(f"Estimated recovery hours: **{playbook['estimated_recovery_hours']}h**")
        st.markdown("**Containment Steps**")
        for idx, step in enumerate(playbook["containment_steps"], start=1):
            st.markdown(f"{idx}. {step}")
        col1, col2 = st.columns(2)
        col1.markdown("**Internal Communication**")
        col1.info(playbook["communication_template"]["internal_msg"])
        col2.markdown("**External Communication**")
        col2.warning(playbook["communication_template"]["external_msg"])
        st.markdown("**Post-Incident Checklist**")
        for idx, item in enumerate(playbook["post_incident_checklist"]):
            st.checkbox(item, key=f"post_{playbook['id']}_{idx}")

st.subheader("2) Recovery Plans")
recovery_df = pd.DataFrame(data["recovery_plans"]).copy()

def _rto_status(rto: int) -> str:
    if rto < 24:
        return "Green"
    if rto <= 48:
        return "Orange"
    return "Red"

recovery_df["RTO Badge"] = recovery_df["rto_hours"].apply(_rto_status)
display = recovery_df.rename(
    columns={
        "name": "Name",
        "backup_type": "Backup Type",
        "backup_frequency": "Frequency",
        "encryption": "Encrypted",
        "offsite": "Offsite",
        "rto_hours": "RTO",
        "rpo_hours": "RPO",
        "testing_schedule": "Testing Schedule",
    }
)[["Name", "Backup Type", "Frequency", "Encrypted", "Offsite", "RTO", "RPO", "Testing Schedule", "RTO Badge"]]

rp1, rp2, rp3 = st.columns(3)
backup_filter = rp1.multiselect(
    "Filter Backup Type",
    sorted(display["Backup Type"].unique()),
    default=sorted(display["Backup Type"].unique()),
)
encrypt_filter = rp2.multiselect("Filter Encrypted", [True, False], default=[True, False])
offsite_filter = rp3.multiselect("Filter Offsite", [True, False], default=[True, False])
display = display[
    display["Backup Type"].isin(backup_filter)
    & display["Encrypted"].isin(encrypt_filter)
    & display["Offsite"].isin(offsite_filter)
]
st.dataframe(display, width="stretch")

st.subheader("3) Incident Tracker (Live)")
with st.form("incident_form", clear_on_submit=True):
    c1, c2 = st.columns(2)
    incident_type = c1.selectbox("Incident Type", ["Ransomware", "Phishing", "Data Breach", "Malware", "DDoS"])
    severity = c2.selectbox("Severity", ["Critical", "High", "Medium", "Low"])
    description = st.text_area("Description")
    submitted = st.form_submit_button("Log Incident")
    if submitted and description.strip():
        now = datetime.now(timezone.utc).isoformat()
        incident_id = f"INC-{len(st.session_state.incidents) + 1:04d}"
        st.session_state.incidents.append(
            {
                "incident_id": incident_id,
                "incident_type": incident_type,
                "severity": severity,
                "description": description.strip(),
                "status": "Detected",
                "created_at": now,
                "updated_at": now,
            }
        )
        st.success(f"Incident {incident_id} logged.")

if st.session_state.incidents:
    inc_df = pd.DataFrame(st.session_state.incidents)
    status_options = sorted(inc_df["status"].unique())
    status_filter = st.multiselect("Filter Incident Status", status_options, default=status_options)
    inc_df = inc_df[inc_df["status"].isin(status_filter)]
    st.dataframe(inc_df, width="stretch")
    filtered_ids = set(inc_df["incident_id"].tolist())
    for incident in st.session_state.incidents:
        if incident["incident_id"] not in filtered_ids:
            continue
        col1, col2 = st.columns([2, 1])
        col1.write(f"{incident['incident_id']} - {incident['incident_type']} ({incident['status']})")
        if col2.button(f"Advance to {_next_status(incident['status'])}", key=f"adv_{incident['incident_id']}"):
            incident["status"] = _next_status(incident["status"])
            incident["updated_at"] = datetime.now(timezone.utc).isoformat()
            st.rerun()
else:
    st.info("No incidents logged yet.")

st.plotly_chart(recovery_timeline(st.session_state.incidents), width="stretch")

st.subheader("4) Recovery Time Simulator")
hours = st.slider("Hours since incident", min_value=0, max_value=120, value=12, step=1)
rows: List[Dict[str, float]] = []
for playbook in data["playbooks"]:
    est = max(1, int(playbook["estimated_recovery_hours"]))
    progress = min(100, round((hours / est) * 100, 2))
    rows.append({"Incident Type": playbook["incident_type"], "Progress %": progress, "Hours": hours})

progress_df = pd.DataFrame(rows)
line_fig = px.line(
    progress_df,
    x="Hours",
    y="Progress %",
    color="Incident Type",
    markers=True,
    range_y=[0, 100],
    title="Simulated Recovery Progress",
)
st.plotly_chart(line_fig, width="stretch")

rto_target = min(plan["rto_hours"] for plan in data["recovery_plans"])
if hours <= rto_target:
    st.success(f"RTO target met (current: {hours}h, target: {rto_target}h).")
else:
    st.error(f"RTO target missed (current: {hours}h, target: {rto_target}h).")
