"""Page 2 - Protect & Detect."""

from __future__ import annotations

from typing import Any, Dict, List

import pandas as pd
import streamlit as st

from module2_protect_detect import calculate_control_coverage, simulate_detection_event
from utils.charts import control_gauge, priority_matrix
from utils.state import ensure_session_state, rebuild_derived_state


def _refresh_data() -> None:
    rebuild_derived_state()


def _apply_editor_updates(edited: pd.DataFrame, source_controls: List[Dict[str, Any]]) -> None:
    status_by_id = dict(zip(edited["id"], edited["Implemented"]))
    for control in source_controls:
        control["implemented"] = bool(status_by_id.get(control["id"], control["implemented"]))


st.title("Protect & Detect")
data = ensure_session_state()
_refresh_data()

st.subheader("1) Control Coverage Gauge")
st.plotly_chart(control_gauge(data["control_coverage"]), width="stretch")

st.subheader("2) Controls Checklist")
categories = sorted({control["category"] for control in data["controls"]})
tabs = st.tabs(categories)
for category, tab in zip(categories, tabs):
    with tab:
        subset = [c for c in data["controls"] if c["category"] == category]
        ctrl_df = pd.DataFrame(subset).copy()
        display_df = ctrl_df.rename(
            columns={
                "name": "Name",
                "category": "Category",
                "cost_level": "Cost Level",
                "complexity": "Complexity",
                "impact": "Impact",
                "implemented": "Implemented",
                "id": "id",
            }
        )[
            ["id", "Name", "Category", "Cost Level", "Complexity", "Impact", "Implemented"]
        ]
        edited = st.data_editor(
            display_df,
            key=f"controls_editor_{category}",
            width="stretch",
            hide_index=True,
            disabled=["id", "Name", "Category", "Cost Level", "Complexity", "Impact"],
        )
        _apply_editor_updates(edited, data["controls"])

_refresh_data()
st.caption(f"Live coverage: **{data['control_coverage']}%**")

st.subheader("3) Detection Mechanisms")
detect_df = pd.DataFrame(data["detection_mechanisms"])
dc1, dc2 = st.columns(2)
indicator_filter = dc1.multiselect(
    "Filter Indicator Type",
    sorted(detect_df["indicator_type"].unique()),
    default=sorted(detect_df["indicator_type"].unique()),
)
severity_filter = dc2.multiselect(
    "Filter Severity",
    sorted(detect_df["severity"].unique()),
    default=sorted(detect_df["severity"].unique()),
)
detect_df = detect_df[
    detect_df["indicator_type"].isin(indicator_filter) & detect_df["severity"].isin(severity_filter)
]
st.dataframe(detect_df, width="stretch")

for row in detect_df.to_dict(orient="records"):
    btn_key = f"simulate_{row['id']}"
    if st.button(f"Simulate Alert - {row['name']}", key=btn_key):
        alert = simulate_detection_event(row["indicator_type"])
        message = f"{alert['event_type']} | {alert['severity']} | {alert['description']}"
        if alert["severity"] in ("Critical", "High"):
            st.error(message)
        else:
            st.warning(message)
        st.info(f"Recommended action: {alert['recommended_action']}")

st.subheader("4) Control Priority Matrix")
st.plotly_chart(priority_matrix(data["controls"]), width="stretch")
