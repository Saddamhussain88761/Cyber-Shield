"""Session-state initialization shared by Streamlit pages.

Streamlit multipage apps can execute a page script directly (e.g., via refresh,
deep link, or after a crash). This module ensures required session keys exist.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict

import streamlit as st

from module1_govern_identify import generate_risk_register
from module2_protect_detect import calculate_control_coverage
from module4_integration import (
    aggregate_risk_data,
    calculate_nist_maturity,
    generate_full_report,
    generate_risk_heatmap_data,
)
from sample_data import get_sme_scenarios


def ensure_session_state(default_scenario_key: str = "retail_ransomware") -> Dict[str, Any]:
    """Ensure required session state keys exist and return current_data."""
    if "all_scenarios" not in st.session_state:
        st.session_state.all_scenarios = get_sme_scenarios()
    if "selected_scenario_key" not in st.session_state:
        st.session_state.selected_scenario_key = default_scenario_key
    if "incidents" not in st.session_state:
        st.session_state.incidents = []
    if "policy_checks" not in st.session_state:
        st.session_state.policy_checks = {}

    key = st.session_state.selected_scenario_key
    if "current_data" not in st.session_state:
        st.session_state.current_data = deepcopy(st.session_state.all_scenarios[key])
        rebuild_derived_state()
        st.session_state.baseline_summary = deepcopy(st.session_state.current_data["summary"])
        st.session_state.baseline_coverage = st.session_state.current_data["control_coverage"]

    return st.session_state.current_data


def rebuild_derived_state() -> None:
    """Recompute all derived values for the active scenario."""
    data: Dict[str, Any] = st.session_state.current_data
    risk_register = generate_risk_register(data["assets"])
    data["risk_register"] = risk_register
    data["summary"] = aggregate_risk_data(risk_register)
    data["maturity_scores"] = calculate_nist_maturity(
        data["controls"], data["playbooks"], data["policies"], data["assets"]
    )
    data["heatmap"] = generate_risk_heatmap_data(risk_register)
    data["control_coverage"] = calculate_control_coverage(data["controls"])
    data["report"] = generate_full_report(data)

