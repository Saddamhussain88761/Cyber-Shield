"""Reusable Plotly chart builders for SME CyberShield."""

from __future__ import annotations

from typing import Any, Dict, List

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

PRIMARY_COLOR = "#1f4e79"

RISK_COLORS = {
    "Critical": "#b22222",
    "High": "#ff8c00",
    "Medium": "#f1c232",
    "Low": "#2e8b57",
}


def risk_heatmap(risk_register: List[Dict[str, Any]]) -> go.Figure:
    matrix = [[0 for _ in range(5)] for _ in range(5)]
    for risk in risk_register:
        likelihood = int(risk.get("likelihood", 1))
        impact = int(risk.get("impact", 1))
        if 1 <= likelihood <= 5 and 1 <= impact <= 5:
            matrix[impact - 1][likelihood - 1] += 1

    fig = go.Figure(
        data=go.Heatmap(
            z=matrix,
            x=[1, 2, 3, 4, 5],
            y=[1, 2, 3, 4, 5],
            colorscale=[[0, "#2e8b57"], [0.5, "#f1c232"], [1, "#b22222"]],
            text=matrix,
            texttemplate="%{text}",
            colorbar=dict(title="Risk Count"),
        )
    )
    fig.update_layout(
        title="Risk Exposure Heatmap",
        xaxis_title="Likelihood",
        yaxis_title="Impact",
        template="plotly_white",
    )
    return fig


def nist_radar(maturity_scores: Dict[str, float]) -> go.Figure:
    axes = ["Govern", "Identify", "Protect", "Detect", "Respond", "Recover"]
    current = [float(maturity_scores.get(axis, 0.0)) for axis in axes]
    target = [5, 5, 5, 5, 5, 5]

    fig = go.Figure()
    fig.add_trace(
        go.Scatterpolar(
            r=current + [current[0]],
            theta=axes + [axes[0]],
            fill="toself",
            name="Current",
            line=dict(color=PRIMARY_COLOR),
        )
    )
    fig.add_trace(
        go.Scatterpolar(
            r=target + [target[0]],
            theta=axes + [axes[0]],
            fill="none",
            name="Target",
            line=dict(color="#7f7f7f", dash="dash"),
        )
    )
    fig.update_layout(
        title="NIST CSF 2.0 Maturity Assessment",
        polar=dict(radialaxis=dict(visible=True, range=[0, 5])),
        template="plotly_white",
    )
    return fig


def control_gauge(coverage_pct: float) -> go.Figure:
    fig = go.Figure(
        go.Indicator(
            mode="gauge+number",
            value=coverage_pct,
            title={"text": "Control Coverage (%)"},
            gauge={
                "axis": {"range": [0, 100]},
                "bar": {"color": PRIMARY_COLOR},
                "steps": [
                    {"range": [0, 50], "color": "#f4cccc"},
                    {"range": [50, 75], "color": "#fce5cd"},
                    {"range": [75, 100], "color": "#d9ead3"},
                ],
                "threshold": {"line": {"color": "black", "width": 3}, "value": 75},
            },
        )
    )
    fig.update_layout(template="plotly_white")
    return fig


def priority_matrix(controls: List[Dict[str, Any]]) -> go.Figure:
    cost_map = {"Low": 1, "Medium": 2, "High": 3}
    impact_map = {"Low": 1, "Medium": 2, "High": 3}
    complexity_map = {"Low": 20, "Medium": 35, "High": 50}

    df = pd.DataFrame(controls).copy()
    if df.empty:
        return px.scatter(title="Control Priority Matrix — Quick wins in bottom-right quadrant")

    df["cost_score"] = df["cost_level"].map(cost_map).fillna(1)
    df["impact_score"] = df["impact"].map(impact_map).fillna(1)
    df["bubble_size"] = df["complexity"].map(complexity_map).fillna(20)

    fig = px.scatter(
        df,
        x="cost_score",
        y="impact_score",
        size="bubble_size",
        color="category",
        text="name",
        hover_data=["cost_level", "impact", "complexity", "implemented"],
        title="Control Priority Matrix — Quick wins in bottom-right quadrant",
    )
    fig.update_traces(textposition="top center")
    fig.update_layout(
        xaxis=dict(title="Cost (Low to High)", tickvals=[1, 2, 3], ticktext=["Low", "Medium", "High"]),
        yaxis=dict(
            title="Impact (Low to High)",
            tickvals=[1, 2, 3],
            ticktext=["Low", "Medium", "High"],
        ),
        template="plotly_white",
    )
    return fig


def recovery_timeline(incidents: List[Dict[str, Any]]) -> go.Figure:
    if not incidents:
        fig = go.Figure()
        fig.update_layout(
            title="Incident Recovery Timeline",
            xaxis_title="Time",
            yaxis_title="Incident ID",
            template="plotly_white",
            annotations=[
                dict(
                    text="No incidents logged yet",
                    x=0.5,
                    y=0.5,
                    xref="paper",
                    yref="paper",
                    showarrow=False,
                    font=dict(color=PRIMARY_COLOR, size=14),
                )
            ],
        )
        return fig
    df = pd.DataFrame(incidents).copy()
    df["start"] = pd.to_datetime(df["created_at"], errors="coerce")
    df["finish"] = pd.to_datetime(df["updated_at"], errors="coerce")
    fig = px.timeline(
        df,
        x_start="start",
        x_end="finish",
        y="incident_id",
        color="status",
        hover_data=["incident_type", "severity", "status"],
        title="Incident Recovery Timeline",
        color_discrete_map=RISK_COLORS,
    )
    fig.update_layout(template="plotly_white")
    return fig


def scenario_comparison(rows: List[Dict[str, Any]]) -> go.Figure:
    df = pd.DataFrame(rows)
    if df.empty:
        return px.bar(title="Scenario Comparison")

    melted = df.melt(
        id_vars=["Scenario"],
        value_vars=["Risk Score", "Control Coverage", "NIST Maturity"],
        var_name="Metric",
        value_name="Value",
    )
    fig = px.bar(
        melted,
        x="Scenario",
        y="Value",
        color="Metric",
        barmode="group",
        title="Scenario Comparison",
        color_discrete_sequence=[PRIMARY_COLOR, "#4a86e8", "#6fa8dc"],
    )
    fig.update_layout(template="plotly_white")
    return fig
