"""Export utilities for PDF and JSON outputs."""

from __future__ import annotations

import json
from io import BytesIO
from typing import Any, Dict, Iterable, List

from fpdf import FPDF


def _wrap_long_tokens(text: str, chunk: int = 40) -> str:
    """Insert spaces into very long tokens so FPDF can wrap them."""
    parts: List[str] = []
    for token in text.split(" "):
        if len(token) <= chunk:
            parts.append(token)
            continue
        pieces = [token[i : i + chunk] for i in range(0, len(token), chunk)]
        parts.append(" ".join(pieces))
    return " ".join(parts)


def _safe_lines(text: str, max_len: int = 140) -> Iterable[str]:
    """Yield reasonably-sized lines to avoid FPDF width edge-cases."""
    text = _wrap_long_tokens(str(text))
    for paragraph in text.splitlines() or [""]:
        paragraph = paragraph.strip()
        if not paragraph:
            yield ""
            continue
        start = 0
        while start < len(paragraph):
            end = min(len(paragraph), start + max_len)
            yield paragraph[start:end]
            start = end


def _safe_multicell(pdf: FPDF, text: str, h: int = 6) -> None:
    """Write text robustly even if FPDF can't auto-wrap a token."""
    pdf.set_x(pdf.l_margin)
    for line in _safe_lines(text):
        try:
            pdf.multi_cell(0, h, line)
        except Exception:
            # Last-resort: shrink font slightly and retry once.
            current_size = getattr(pdf, "font_size_pt", 10) or 10
            pdf.set_font(pdf.font_family, size=max(8, int(current_size) - 2))
            pdf.set_x(pdf.l_margin)
            pdf.multi_cell(0, h, line)


def generate_pdf_report(report_payload: Dict[str, Any]) -> bytes:
    """Create a concise executive PDF report and return bytes."""
    pdf = FPDF()
    pdf.set_margins(12, 12, 12)
    pdf.set_auto_page_break(auto=True, margin=12)
    pdf.add_page()

    pdf.set_font("Arial", "B", 16)
    pdf.cell(0, 10, "SME CyberShield - Executive Risk Report", ln=True)

    org = report_payload.get("organization", {})
    summary = report_payload.get("executive_summary", {})
    detailed = report_payload.get("detailed_sections", {})

    pdf.set_font("Arial", "", 11)
    pdf.ln(2)
    _safe_multicell(pdf, f"Organization: {org.get('name', 'N/A')} ({org.get('sector', 'N/A')})", h=7)
    top_threats = ", ".join(t.get("threat", "") for t in summary.get("top_threats", []))
    _safe_multicell(
        pdf,
        f"Overall Risk Score: {summary.get('overall_risk_score', 0)} | Top Threats: {top_threats}",
        h=7,
    )

    pdf.ln(2)
    pdf.set_font("Arial", "B", 12)
    pdf.cell(0, 8, "NIST Maturity Scores", ln=True)
    pdf.set_font("Arial", "", 11)
    nist_scores = summary.get("nist_maturity", {})
    for func, score in nist_scores.items():
        pdf.cell(0, 6, f"- {func}: {score}/5", ln=True)

    pdf.ln(2)
    pdf.set_font("Arial", "B", 12)
    pdf.cell(0, 8, "Risk Register (Top 10)", ln=True)
    pdf.set_font("Arial", "", 10)
    risk_register: List[Dict[str, Any]] = detailed.get("risk_register", [])[:10]
    for row in risk_register:
        line = (
            f"{row.get('asset_id')} | {row.get('threat')} | "
            f"Score: {row.get('risk_score')} ({row.get('risk_level')})"
        )
        _safe_multicell(pdf, line, h=6)

    pdf.ln(2)
    pdf.set_font("Arial", "B", 12)
    pdf.cell(0, 8, "Top Recommendations", ln=True)
    pdf.set_font("Arial", "", 10)
    recommendations = []
    for row in risk_register:
        recommendations.append(row.get("recommended_control", ""))
    for rec in list(dict.fromkeys(recommendations))[:5]:
        _safe_multicell(pdf, f"- {rec}", h=6)

    output = BytesIO()
    rendered = pdf.output(dest="S")
    if isinstance(rendered, (bytes, bytearray)):
        output.write(bytes(rendered))
    else:
        output.write(str(rendered).encode("latin-1", errors="ignore"))
    return output.getvalue()


def export_json_bytes(data: Dict[str, Any]) -> bytes:
    """Return pretty JSON bytes for download."""
    return json.dumps(data, indent=2, default=str).encode("utf-8")
