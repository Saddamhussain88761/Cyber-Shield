"""Shared data schemas for the SME cybersecurity risk platform.

These TypedDicts keep module outputs consistent and JSON-serializable.
"""

from __future__ import annotations

from typing import Dict, List, Literal, TypedDict


PriorityLevel = Literal["High", "Medium", "Low"]
RiskLevel = Literal["Critical", "High", "Medium", "Low"]
AssetType = Literal["Hardware", "Software", "Data", "Third-party"]
ControlCategory = Literal[
    "Access Control",
    "Data Protection",
    "Platform Security",
    "Awareness",
]
CostComplexityLevel = Literal["Low", "Medium", "High"]
IndicatorType = Literal["Login", "Network", "Endpoint", "Email"]
IncidentType = Literal["Ransomware", "Phishing", "Data Breach", "Malware", "DDoS"]
IncidentStatus = Literal["Detected", "Contained", "Recovering", "Resolved"]
BackupType = Literal["Automated", "Manual"]


class GovernancePolicy(TypedDict):
    id: str
    title: str
    description: str
    nist_function: Literal["Govern"]
    priority: PriorityLevel
    owner_role: str
    checklist: List[str]


class Asset(TypedDict):
    id: str
    name: str
    type: AssetType
    owner: str
    vulnerabilities: List[str]
    criticality: PriorityLevel


class RiskRegisterEntry(TypedDict):
    asset_id: str
    threat: str
    likelihood: int
    impact: int
    risk_score: int
    risk_level: RiskLevel
    recommended_control: str


class ProtectiveControl(TypedDict):
    id: str
    name: str
    category: ControlCategory
    nist_function: Literal["Protect"]
    cost_level: CostComplexityLevel
    complexity: CostComplexityLevel
    impact: PriorityLevel
    implemented: bool
    description: str
    checklist_items: List[str]


class DetectionMechanism(TypedDict):
    id: str
    name: str
    indicator_type: IndicatorType
    severity: RiskLevel
    description: str
    alert_threshold: str
    response_action: str


class DetectionAlert(TypedDict):
    timestamp: str
    event_type: str
    severity: RiskLevel
    description: str
    recommended_action: str


class IncidentPlaybook(TypedDict):
    id: str
    incident_type: IncidentType
    severity: RiskLevel
    containment_steps: List[str]
    communication_template: Dict[str, str]
    mitigation_steps: List[str]
    post_incident_checklist: List[str]
    estimated_recovery_hours: int


class RecoveryPlan(TypedDict):
    id: str
    name: str
    backup_type: BackupType
    backup_frequency: str
    encryption: bool
    offsite: bool
    rto_hours: int
    rpo_hours: int
    testing_schedule: str
    steps: List[str]


class IncidentRecord(TypedDict):
    incident_id: str
    incident_type: str
    severity: RiskLevel
    description: str
    status: IncidentStatus
    created_at: str
    updated_at: str
